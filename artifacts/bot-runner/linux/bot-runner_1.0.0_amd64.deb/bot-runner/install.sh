#!/bin/bash
set -e
echo "Installing Bot Runner Agent..."
sudo cp BotRunner /usr/local/bin/BotRunner
sudo chmod +x /usr/local/bin/BotRunner
sudo cat > /etc/systemd/system/bot-runner.service << 'SVC'
[Unit]
Description=NextGen Bot Runner Agent
After=network.target

[Service]
Type=simple
ExecStart=/usr/local/bin/BotRunner
Restart=always
RestartSec=10
Environment=ORCHESTRATOR_URL=http://localhost:3001
Environment=RUNNER_MODE=VM

[Install]
WantedBy=multi-user.target
SVC
sudo systemctl daemon-reload
sudo systemctl enable bot-runner
sudo systemctl start bot-runner
echo "Bot Runner Agent installed and started."
